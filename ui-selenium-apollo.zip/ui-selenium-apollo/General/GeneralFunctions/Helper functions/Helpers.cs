 using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;
using Apollo.FinanceOperations.src;
using Apollo.General.GeneralFunctions;
  

namespace Apolo.PowerPlatform.helpers;
  public class Helpers {
  

    IWebDriver driver;
    public void elementDisplayedCheck(String elementXpath) {

        
        
         //identify elements and store it in list
         List<IWebElement> elementList = new List<IWebElement>();
         elementList.AddRange(driver.FindElements(By.XPath(elementXpath)));
         //checking element count in list
         if (elementList.Count > 0){
            Console.WriteLine("----------------------Element is Present-----------------------");
            Console.WriteLine(elementList.Count());
         } else {
            Console.WriteLine("----------------------Element is not Present-------------------");      
         }
      }
      

     }