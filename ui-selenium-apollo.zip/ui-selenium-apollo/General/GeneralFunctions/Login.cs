using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;

namespace Apollo.General.GeneralFunctions
{
    public class LoginPage : Components
    {/*
        private String email = "cva@vab.be";
        private String password = "F1nn1989?";
*/

        private String email = "SA_Selenium_General@vab.be";
        private String password = "^VOjl#eQn63684d3Doaq";
        
        private String urlFO = "https://vab-apo-d365fo-tst01c4b0a58cacc80b05devaos.axcloud.dynamics.com";       
       // private String urlFO = "https://vab-apo-acc.sandbox.operations.dynamics.com";    
        public IWebDriver driver;

        public LoginPage(IWebDriver driver) :  base(driver)
        {
           this.driver=driver;
        }

        
        public String getURLFO(){
            return urlFO;
            
        }
        
    public void LoginFO(IWebDriver driver)
        {
            Console.WriteLine("LoginFO");
            Login(driver);
            base.waitForElement(By.ClassName("modulesList"));
            
        }

        
    public void Login(IWebDriver driver)
        {

            
            Console.WriteLine("LoginFO");
            String pathTxtEmail = "i0116";
            String pathTxtPassword = "i0118";
            String pathBtnSubmit = "idSIButton9";

            Console.WriteLine("LoginFO: Fill in email");
            base.waitForElement(By.Id(pathTxtEmail));
            driver.FindElement(By.Id(pathTxtEmail)).SendKeys(email);

            Console.WriteLine("LoginFO: Submit email");
            driver.FindElement(By.Id(pathBtnSubmit)).Click();
            
            Console.WriteLine("LoginFO: Fill in password");
            base.waitForElement(By.Id(pathTxtPassword));
            driver.FindElement(By.Id(pathTxtPassword)).SendKeys(password);
            
            Console.WriteLine("LoginFO: Submit password");
            driver.FindElement(By.Id(pathBtnSubmit)).Click();
            Thread.Sleep(5000);
            base.waitForElement(By.Id(pathBtnSubmit));            
            Console.WriteLine("LoginFO: Submit session");
            driver.FindElement(By.Id(pathBtnSubmit)).Click();
            base.waitForElement(By.Id("okButtonText_1"));
            driver.FindElement(By.Id("okButtonText_1")).Click();
        }
        
    }
}
