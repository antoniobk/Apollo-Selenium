using OpenQA.Selenium;
using Apollo.Website.lib;

namespace Apollo.Website.src
{
    public class Navigation 
    {
        private IWebDriver driver;
        
        public Navigation(IWebDriver driver) 
        {
            this.driver = driver;
        }
        public void createNewProductAssembly(String productCode,String productAssembly)
        {
           
        }

    }
}