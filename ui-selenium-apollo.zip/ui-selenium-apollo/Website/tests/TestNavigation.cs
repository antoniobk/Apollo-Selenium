using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.Website.lib;
using Apollo.Website.src;
using Apollo.FinanceOperations.lib;
using System.Xml;
using System.Text.Json;


namespace Apollo.Website.tests
{
    public class TestNavigation
    {
        IWebDriver driver;

        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }
/*
        [Test]
        public void NavigateXML()
        {

            Components components = new Components(driver);
            XmlReader xReader = XmlReader.Create("C:\\Users\\CVA\\Documents\\svn\\Selenium\\Website\\navigation.xml");
            
            xReader.ReadToFollowing("HoofdMenu");


            driver.Navigate().GoToUrl("https://tst-apo.vab.be/nl");
        
            components.waitForElement(By.XPath("//a[@gtmlabel='Pechverhelping_En_Reisverzekering']"));
            driver.FindElement(By.XPath("//a[@gtmlabel='Pechverhelping_En_Reisverzekering']")).Click();
            components.waitForElement(By.XPath("//a[@gtmlabel='Pechbijstand']"));
            driver.FindElement(By.XPath("//a[@gtmlabel='Pechbijstand']")).Click();            
            components.waitForElement(By.Id("Dynamicdata.Startdate"));            
        }
*/
        [Test]
        public void NavigateJSON()
        {

            Components components = new Components(driver);

            String navigationJSONData = File.ReadAllText("C:/Users/CVA/Documents/svn/Selenium/Website/data/navigation.json");
            var navigations = JsonSerializer.Deserialize<List<NavigationWebsite>>(navigationJSONData);

            Thread.Sleep(3000);
            driver.Navigate().GoToUrl("https://tst-apo.vab.be/nl");

            if (navigations != null)
            {
                foreach (var navigation in navigations)
                {
                    for (int i = 0; i < 1; i++)
                    {
                        Console.WriteLine($"Wait for {navigation.gtmlabel}");
                        components.waitForElement(By.XPath($"//a[@gtmlabel='{navigation.gtmlabel}']"));
                        Console.WriteLine($"Click {navigation.gtmlabel}");
                        driver.FindElement(By.XPath($"//a[@gtmlabel='{navigation.gtmlabel}']")).Click();

                        
                        
                        Console.WriteLine($"Wait for {navigation.submenuList[i].gtmlabel}");
                        components.waitForElement(By.XPath($"//a[@gtmlabel='{navigation.submenuList[i].gtmlabel}']"));
                        Console.WriteLine($"Click {navigation.submenuList[i].gtmlabel}");
                        driver.FindElement(By.XPath($"//a[@gtmlabel='{navigation.submenuList[i].gtmlabel}']")).Click();
                        Console.WriteLine($"Wait for Startdate");
                        components.waitForElement(By.Id($"Dynamicdata.Startdate"));
                    }
                }
            }


        }


        [OneTimeTearDown]
        public void Close()
        {
            // driver.Quit();
        }

    }
}