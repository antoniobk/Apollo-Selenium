using OpenQA.Selenium;

namespace Apollo.Website.lib
{
    public class NavigationWebsite
    {

        public NavigationWebsite()
        {
        }

        public NavigationWebsite submenu{get;set;}    
        public List<NavigationWebsite> submenuList{get;set;}       

        public String gtmlabel{get;set;}        
        public String? title{get;set;}


    }
}