using OpenQA.Selenium;

namespace Apollo.FinanceOperations.lib
{
    public class NavigationPP : Components
    {
        public IWebDriver driver;

        public NavigationPP(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }


        public void navigatePPMenuByTitle(String titleMenu, String titlePage)
        {
            Console.WriteLine("navigatePPMenu");
            Console.WriteLine("navigatePPMenu: Click on menu - " + titleMenu);
            base.waitForElement(By.XPath("//li[@aria-label='" + titleMenu + "']"));
            driver.FindElement(By.XPath("//li[@aria-label='" + titleMenu + "']")).Click();    

            Console.WriteLine("navigatePPMenu: Wait for page with title - " + titlePage);
            base.waitForElement(By.XPath("//h1[@title='" + titlePage + "']"));
        }

        public void navigatePPMenu(String titleMenu)
        {
            Console.WriteLine("navigatePPMenu");
            Console.WriteLine("navigatePPMenu: Click on menu - " + titleMenu);
            base.waitForElement(By.XPath("//li[@aria-label='" + titleMenu + "']"));
            
        }


    }
}