using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;
using Apollo.FinanceOperations.src;
using Apollo.General.GeneralFunctions;


namespace Apollo.PowerPlatform.tests
{
    public class TestPowerPlatform
    {
        IWebDriver driver;

        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }


        [Test]
        public void createProduct()
        {
            
            LoginPage login = new LoginPage(driver);

            NavigationPP navigation = new NavigationPP(driver);
            driver.Navigate().GoToUrl("https://vab-tst.crm4.dynamics.com/main.aspx?appid=d7a4006c-947b-ec11-8d21-000d3a278fc9&pagetype=control&controlName=MscrmControls.AcceleratedSales.AnchorShellControl");
            login.Login(driver);

            navigation.navigatePPMenuByTitle("Facturen","Mijn facturen");
        }

        [OneTimeTearDown]
        public void Close()
        {
           // driver.Quit();
        }

    }
}