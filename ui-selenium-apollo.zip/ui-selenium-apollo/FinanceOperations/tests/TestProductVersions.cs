using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;
using Apollo.FinanceOperations.src;
using Apollo.General.GeneralFunctions;


namespace Apollo.FinanceOperations.tests
{
    public class TestProductVersions
    {
        IWebDriver driver;
        ProductVersions product;

        [OneTimeSetUp]
        public void Setup()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--incognito");
            options.AddArgument("--start-maximized");
            driver = new ChromeDriver(options);
        }

        [OneTimeSetUp]
        public void LoginFO()
        {
            LoginPage login = new LoginPage(driver);
            NavigationFO navigation = new NavigationFO(driver);
            product = new ProductVersions(driver);

            driver.Navigate().GoToUrl(login.getURLFO());
            login.LoginFO(driver);
            navigation.navigateFOModulesMenu("Contractbeheer", "Productversies");
        }

        [Test]
        public void createProductVersions()
        {
            ErrorHandling error = new ErrorHandling(driver);
            String[] productCodes = { "SeleniumPakket", "SeleniumOnderwaarborg", "SeleniumProduct", "SeleniumHoofdwaarborg" };
            String[] productTypes = { "Pakket", "Onderwaarborg", "Product", "Hoofdwaarborg" };

            Assert.Multiple(() =>
         {
             for (int i = 0; i < productCodes.Length; i++)
             {
                 Console.WriteLine("createProductVersions: productCode = " + productCodes[i]);
                 Console.WriteLine("createProductVersions: productType = " + productTypes[i]);
                 product.createNewProductVersion(productCodes[i], productTypes[i]);
                 product.deleteProductVersion(productCodes[i]);
                 product.searchProductVersion("");
             }
         });
        }

        [OneTimeTearDown]
        public void Close()
        {
           // driver.Quit();
        }

    }
}