using OpenQA.Selenium;
using Apollo.FinanceOperations.lib;

namespace Apollo.FinanceOperations.src
{
    public class ProductAssemblies : Components
    {
        private IWebDriver driver;
        private TableOperations table;
        private ErrorHandling error;

        public ProductAssemblies(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
            this.table = new TableOperations(driver, By.Name("QuickFilterControl_Input"));
            this.error = new ErrorHandling(driver);
        }
        public void createNewProductAssembly(String productCode,String productAssembly)
        {
            Console.WriteLine("createNewProductAssembly");
            Console.WriteLine("createNewProductAssembly: Click button create New Product Assembly");
            base.waitForElement(By.Name("SystemDefinedNewButton"));
            driver.FindElement(By.Name("SystemDefinedNewButton")).Click();
            Thread.Sleep(3000);
            IList<IWebElement> editProductAssemblies = table.getActiveElements();
            String productCodeId = editProductAssemblies[0].GetAttribute("id");
            driver.FindElement(By.Id(productCodeId)).SendKeys(productCode);
            driver.FindElement(By.Id(productCodeId)).SendKeys(Keys.Tab);

            String productAssemblyId = editProductAssemblies[3].GetAttribute("id");
            driver.FindElement(By.Id(productAssemblyId)).SendKeys(productAssembly);
            driver.FindElement(By.Id(productAssemblyId)).SendKeys(Keys.Tab);


            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//button[@data-dyn-controlname='SystemDefinedSaveButton']")).Click();
            error.checkErrorHandling();
        }
        public void deleteProductAssembly()
        {
            table.selectFirstRow();
            table.deleteElement();
        }
    }
}