using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Apollo.FinanceOperations.lib
{
    public class Components
    {
        private IWebDriver driver;

        public Components(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void setDriver(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebDriver getDriver()
        {
            return driver;
            
        }

        public void waitForElement(By htmlElement)
        {            
            Console.WriteLine("waitForElement");
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, 30));
            var element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(htmlElement));
        }

        public void selectElement(By selectElement, String selectValue)
        {
            Console.WriteLine("selectElementByName");
            waitForElement(selectElement);
            IWebElement productType = driver.FindElement(selectElement);
            driver.FindElement(selectElement).Click();
            String id = productType.GetAttribute("aria-controls");
            Console.WriteLine("id - " + id);
            String xpathList = "//*[@id='" + id + "']/li";
            waitForElement(By.XPath(xpathList));

            Console.WriteLine("selectElementByName: Search elements");
            IList<IWebElement> productTypes = driver.FindElements(By.XPath(xpathList));
            foreach (IWebElement type in productTypes)
            {
                String text = type.GetAttribute("innerHTML");
                String typeId = type.GetAttribute("id");

                if (text.Equals(selectValue))
                {         
                    Console.WriteLine("selectElementByName: Actual value - " + text);
                    driver.FindElement(By.Id(typeId)).Click();
                }
            }
        }

        public void selectDateByName(String htmlName, String date)
        {
            Console.WriteLine("selectDateByName");
            Console.WriteLine("selectDateByName: Wait for Element");
            waitForElement(By.Name(htmlName));
            Console.WriteLine("selectDateByName: Fill in date");
            driver.FindElement(By.Name(htmlName)).SendKeys(date);
            Console.WriteLine("selectDateByName: Lose focus date");
            driver.FindElement(By.Name(htmlName)).SendKeys(Keys.Tab);
        }


        public String generateRandomNumber(int lowerBound, int upperBound)
        {
            Console.WriteLine("generateRandomNumber");
            Random random = new Random();
            return random.Next(lowerBound, upperBound).ToString();
        }

      /*  public void selectLookupByName(By elementLookup, String selectValue)
        {
            Console.WriteLine("selectElementByName");
            waitForElement(elementLookup);
            IWebElement productType = driver.FindElement(By.Name(htmlName));
            driver.FindElement(elementLookup).Click();
            String id = productType.GetAttribute("aria-controls");
            Console.WriteLine("id - " + id);
            String xpathList = "//*[@id='" + id + "']/li";
            waitForElement(By.XPath(xpathList));

            Console.WriteLine("selectElementByName: Search elements");
            IList<IWebElement> productTypes = driver.FindElements(By.XPath(xpathList));
            foreach (IWebElement type in productTypes)
            {
                String text = type.GetAttribute("innerHTML");
                String typeId = type.GetAttribute("id");

                if (text.Equals(selectValue))
                {         
                    Console.WriteLine("selectElementByName: Actual value - " + text);
                    driver.FindElement(By.Id(typeId)).Click();
                }
            }
        }*/

        
    }
}