using OpenQA.Selenium;

namespace Apollo.FinanceOperations.lib
{
    public class ErrorHandling : Components
    {
        public IWebDriver driver;
        private int timeOut = 5000;

        public ErrorHandling(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }

        public Boolean checkErrorHandling()
        {
            Console.WriteLine("checkErrorHandling");
            Boolean errorHandlingExists = false;
            Boolean isProcessDialogIsPresent;
            Boolean isDialogIsPresent;
            Boolean isErrordialogIsPresent;

            isProcessDialogIsPresent = checkProcessDialogIsPresent();
            isDialogIsPresent = checkDialogIsPresent();
            isErrordialogIsPresent = checkErrorDialogIsPresent();

            if (isProcessDialogIsPresent)
            {
                Console.WriteLine("checkErrorHandling: isProcessDialogIsPresent: true");
            }
            else
            {
                Console.WriteLine("checkErrorHandling: isProcessDialogIsPresent false");
            }

            if (isDialogIsPresent)
            {
                Console.WriteLine("checkErrorHandling: isDialogIsPresent true");
            }
            else
            {
                Console.WriteLine("checkErrorHandling: isDialogIsPresent false");
            }

            if (isErrordialogIsPresent)
            {
                Console.WriteLine("checkErrorHandling: isErrordialogIsPresent true");
            }
            else
            {
                Console.WriteLine("checkErrorHandling: isErrordialogIsPresent false");
            }

            if (isProcessDialogIsPresent || isDialogIsPresent || isErrordialogIsPresent)
            {
                Console.WriteLine("checkErrorHandling: errorHandlingExists true");
                errorHandlingExists = true;
            }
            else
            {
                Console.WriteLine("checkErrorHandling: errorHandlingExists false");
                errorHandlingExists = false;
            }

            Assert.IsFalse(errorHandlingExists, "checkErrorHandling: Errorhandling is visible");

            return errorHandlingExists;
        }

        public Boolean IsElementPresent(By by)
        {
            Console.WriteLine("IsElementPresent");
            try
            {
                driver.FindElement(by);
                Console.WriteLine("IsElementPresent: Element is present");
                return true;
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine("IsElementPresent: Element is not present");
                return false;
            }
        }
        public int getTimeOut()
        {
            Console.WriteLine("getTimeOut");
            return timeOut;
        }

      /*  public Boolean IsElementPresentTimeout(By by)
        {
            Console.WriteLine("IsElementPresentTimeout");
            Boolean elementIsPresent = false;
            elementIsPresent = IsElementPresent(By.ClassName("spinner-apo"));
            while (elementIsPresent)
            {

                Console.WriteLine("checkDialogIsPresent: Check if dialog is present, counter: " + counter);
                counter++;
                Thread.Sleep(timeOut);
                dialogIsPresent = IsElementPresent(By.ClassName("dialog-popup-content"));

                if (dialogIsPresent && counter <= 3)
                {
                    Console.WriteLine("checkDialogIsPresent: Dialog is present");
                }
                else if (dialogIsPresent && counter > 3)
                {
                    Console.WriteLine("checkDialogIsPresent: Dialog is present, counter expired");
                    break;
                }
                else if (!dialogIsPresent)
                {
                    Console.WriteLine("checkDialogIsPresent: Dialog is closed");
                    dialogIsPresent = false;
                    break;
                }
            }
            return elementIsPresent;

        }*/
        private Boolean checkDialogIsPresent()
        {
            Console.WriteLine("checkDialogIsPresent");
            Boolean dialogIsPresent = false;
            int counter = 1;

            Thread.Sleep(timeOut);
            dialogIsPresent = IsElementPresent(By.ClassName("dialog-popup-content"));
            while (dialogIsPresent)
            {
                Console.WriteLine("checkDialogIsPresent: Check if dialog is present, counter: " + counter);
                counter++;
                Thread.Sleep(timeOut);
                dialogIsPresent = IsElementPresent(By.ClassName("dialog-popup-content"));

                if (dialogIsPresent && counter <= 3)
                {
                    Console.WriteLine("checkDialogIsPresent: Dialog is present");
                }
                else if (dialogIsPresent && counter > 3)
                {
                    Console.WriteLine("checkDialogIsPresent: Dialog is present, counter expired");
                    break;
                }
                else if (!dialogIsPresent)
                {
                    Console.WriteLine("checkDialogIsPresent: Dialog is closed");
                    dialogIsPresent = false;
                    break;
                }
            }
            return dialogIsPresent;
        }

       

        public Boolean checkProcessDialogIsPresent()
        {
            Console.WriteLine("checkProcessDialogIsPresent");
            Boolean dialogIsPresent = false;
            String style;
            String expectedStyle = "display: none;";
            int counter = 1;


            Thread.Sleep(timeOut);
            style = driver.FindElement(By.Id("ShellBlockingDiv")).GetAttribute("style");
            Console.WriteLine("checkProcessDialogIsPresent: attribute style process dialog = " + style);

            while (style.Equals(expectedStyle))
            {
                Console.WriteLine("checkProcessDialogIsPresent: Check if dialog is present, counter: " + counter);
                counter++;
                Thread.Sleep(timeOut);
                style = driver.FindElement(By.Id("ShellBlockingDiv")).GetAttribute("style");
                Console.WriteLine("checkProcessDialogIsPresent: attribute style process dialog = " + style);

                if (!style.Equals(expectedStyle) && counter <= 3)
                {
                    Console.WriteLine("checkProcessDialogIsPresent: Dialog is present");
                    dialogIsPresent = true;
                }
                else if (!style.Equals(expectedStyle) && counter > 3)
                {
                    Console.WriteLine("checkProcessDialogIsPresent: Dialog is present, counter expired");
                    dialogIsPresent = true;
                    break;
                }
                else if (style.Equals(expectedStyle))
                {
                    Console.WriteLine("checkProcessDialogIsPresent: Dialog is closed");
                    dialogIsPresent = false;
                    break;
                }
            }
            return dialogIsPresent;
        }

        private Boolean checkErrorDialogIsPresent()
        {
            Console.WriteLine("checkErrorDialogIsPresent");
            Boolean dialogIsPresent = false;
            IList<IWebElement> messages = driver.FindElements(By.ClassName("messageBar-message"));

            foreach (IWebElement message in messages)
            {
                String title = message.GetAttribute("title");
                if (!String.IsNullOrEmpty(title))
                {
                    Console.WriteLine("checkErrorDialogIsPresent: Error: " + title);
                    dialogIsPresent = true;
                    if (dialogIsPresent)
                    {
                        IList<IWebElement> closeButtons = driver.FindElements(By.XPath("//button[@aria-label='Sluiten']"));
                        foreach (IWebElement closeButton in closeButtons)
                        {
                            String controlName = closeButton.GetAttribute("data-dyn-controlname");
                            if (controlName.Equals("MessageBarClose"))
                            {
                                Console.WriteLine("checkErrorDialogIsPresent: Close error");
                                closeButton.Click();
                            }
                        }
                    }
                }

            }
            return dialogIsPresent;
        }
    }
}